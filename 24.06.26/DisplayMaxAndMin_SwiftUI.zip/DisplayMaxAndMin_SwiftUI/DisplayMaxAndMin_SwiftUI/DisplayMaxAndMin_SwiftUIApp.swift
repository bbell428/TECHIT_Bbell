//
//  DisplayMaxAndMin_SwiftUIApp.swift
//  DisplayMaxAndMin_SwiftUI
//
//  Created by 홍재민 on 6/26/24.
//

import SwiftUI

@main
struct DisplayMaxAndMin_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
