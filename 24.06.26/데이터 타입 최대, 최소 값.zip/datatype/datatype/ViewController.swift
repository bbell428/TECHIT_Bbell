//
//  ViewController.swift
//  datatype
//
//  Created by 김수민 on 6/26/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var maxLabel: UILabel!
    @IBOutlet weak var minLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func IntButton(_ sender: Any) {
        maxLabel.text = "max : \(Int.max)"
        minLabel.text = "min : \(Int.min)"
    }
    
    
    @IBAction func Int8Button(_ sender: Any) {
        maxLabel.text = "max : \(Int8.max)"
        minLabel.text = "min : \(Int8.min)"
    }
    
    
    @IBAction func Int16Button(_ sender: Any) {
        maxLabel.text = "max : \(Int16.max)"
        minLabel.text = "min : \(Int16.min)"
    }
    
    
    @IBAction func UIntButton(_ sender: Any) {
        maxLabel.text = "max : \(UInt.max)"
        minLabel.text = "min : \(UInt.min)"
    }
    
    @IBAction func FloatButton(_ sender: Any) {
        maxLabel.text = "max : \(Float.greatestFiniteMagnitude)"
        minLabel.text = "min : \(Float.leastNormalMagnitude)"
    }
    
    @IBAction func DoubleButton(_ sender: Any) {
        maxLabel.text = "max : \(Double.greatestFiniteMagnitude)"
        minLabel.text = "min : \(Double.leastNormalMagnitude)"
    }
    
    
    
}

