//
//  TypeCalcUIApp.swift
//  TypeCalcUI
//
//  Created by Jongwook Park on 6/11/24.
//

import SwiftUI

@main
struct TypeCalcUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
