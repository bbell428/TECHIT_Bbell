import SwiftUI

struct AppInfo: Identifiable {
    var id: UUID = UUID()
    var name: String
    var category: Category
    var urlString: String
    var ads: String
    
    var url: URL {
        get {
            return URL(string: urlString)!
        }
    }
}
