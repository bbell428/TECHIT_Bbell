import SwiftUI

let apps: [AppInfo] = [
    AppInfo(name: "Xcode", category: .개발자도구, urlString: "https://apps.apple.com/kr/app/xcode/id497799835?mt=12", ads: "Xcode 15를 사용하면 앱 개발자들이 전체 Apple 플랫폼용 앱을 개발, 테스트, 배포할 수 있다."),
    AppInfo(name: "TaskTrack Timer", category: .유틸리티, urlString: "https://apps.apple.com/kr/app/tasktrack-timer/id6477932169", ads: "시간을 지정해 할일을 하려는 사람들에게 지정된 시간 후에 알림을 보내준다."),
]
