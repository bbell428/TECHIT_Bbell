import SwiftUI
import Charts

struct ContentView: View {
    var body: some View {        
        NavigationStack {
            List {
                ForEach(apps) { app in
                    GroupBox("\(app.name)") {
                        HStack {
                            VStack(alignment: .leading) {
                                Text("\(app.category)")
                                    .font(.subheadline)
                                Text("\(app.ads)")
                                    .font(.caption)
                                
                                Link(destination: app.url, label: {
                                    Text("App Store에서 보기")
                                        .font(.footnote)
                                })
                            }
                            Spacer()
                        }
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("My Favorite Apps")
        }
    }
}
