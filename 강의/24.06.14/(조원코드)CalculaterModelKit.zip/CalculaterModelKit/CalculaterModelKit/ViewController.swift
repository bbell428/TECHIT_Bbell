//
//  ViewController.swift
//  CalculaterModelKit
//
//  Created by 홍재민 on 6/14/24.
//

import UIKit

class Calc {
    var number1: Int = 0
    var number2: Int = 0
    
    func add() -> String {
        "\(number1 + number2)"
    }
    
    func minus() -> String {
        "\(number1 - number2)"
    }
    
    func mul() -> String {
        "\(number1 * number2)"
    }
    
    func div() -> String {
        if number2 == 0 {
            "Error"
        } else {
            "\(number1 / number2)"
        }
    }
}

class ViewController: UIViewController {

    var calculater: Calc = Calc()
    
    @IBOutlet weak var firstNumLabel: UILabel!
    @IBOutlet weak var secondNumLabel: UILabel!
    @IBOutlet weak var ResultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNumLabel.layer.masksToBounds = true
        firstNumLabel.layer.cornerRadius = 10
        
        secondNumLabel.layer.masksToBounds = true
        secondNumLabel.layer.cornerRadius = 10
        
        firstNumLabel.text = "\(calculater.number1)"
        secondNumLabel.text = "\(calculater.number2)"
    }

    
    @IBAction func IncreaseFirstNumber(_ sender: Any) {
        calculater.number1 += 1
        firstNumLabel.text = "\(calculater.number1)"
    }
    
    
    @IBAction func DecreaseFirstNumber(_ sender: Any) {
        calculater.number1 -= 1
        firstNumLabel.text = "\(calculater.number1)"
    }
    
    
    @IBAction func IncreaseSecondNumber(_ sender: Any) {
        calculater.number2 += 1
        secondNumLabel.text = "\(calculater.number2)"
    }
    
    
    @IBAction func DecreaseSecondNumber(_ sender: Any) {
        calculater.number2 -= 1
        secondNumLabel.text = "\(calculater.number2)"
    }
    
    
    @IBAction func PlusButton(_ sender: Any) {
        ResultLabel.text = calculater.add()
    }
    
    
    @IBAction func MinusButton(_ sender: Any) {
        ResultLabel.text = calculater.minus()
    }
    
    
    @IBAction func MultyplyButton(_ sender: Any) {
        ResultLabel.text = calculater.mul()
    }
    
    
    @IBAction func DivideButton(_ sender: Any) {
        ResultLabel.text = calculater.div()
    }
    
    
    @IBAction func ResetAll(_ sender: Any) {
        calculater.number1 = 0
        calculater.number2 = 0
        
        firstNumLabel.text = "\(calculater.number1)"
        secondNumLabel.text = "\(calculater.number2)"
        ResultLabel.text = "0"
    }
}

