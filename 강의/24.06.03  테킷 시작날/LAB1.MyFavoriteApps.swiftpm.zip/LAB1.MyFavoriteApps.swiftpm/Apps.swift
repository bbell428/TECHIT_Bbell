import SwiftUI

let apps: [AppInfo] = [
    AppInfo(
        name: "Xcode",
        category: .개발자도구,
        urlString: "https://apps.apple.com/kr/app/xcode/id497799835?mt=12",
        ads: "Xcode 15를 사용하면 앱 개발자들이 전체 Apple 플랫폼용 앱을 개발, 테스트, 배포할 수 있다."),
    
    AppInfo(
        name: "TaskTrack Timer",
        category: .유틸리티, urlString: "https://apps.apple.com/kr/app/tasktrack-timer/id6477932169", ads: "시간을 지정해 할일을 하려는 사람들에게 지정된 시간 후에 알림을 보내준다."),
    
    AppInfo(
        name: "Microsoft Word",
        category: .생산성,
        urlString: "https://apps.apple.com/kr/app/microsoft-word/id462054704?mt=12",
        ads: "문서를 만들고, 편집하고, 공동 작업하고 공유하는 앱"),
    
    
    // 6. 이주노
    AppInfo(
        name: "KakaoTalk",
        category: .소셜네트워킹,
        urlString: "https://apps.apple.com/kr/app/kakaotalk/id869223134?mt=12",
        ads: "전세계 어디서나 무료로 즐기는 그룹채팅 및 1:1 채팅 앱"),
    
    AppInfo(
        name: "YouTube",
        category: .사진및비디오,
        urlString: "https://apps.apple.com/kr/app/youtube/id544007664",
        ads: "가장 인기 있는 뮤직 비디오에서부터 게임, 패션 뷰티, 뉴스, 학습 등에 이르기까지 전 세계의 인기 동영상을 확인할 수 있습니다."),
    
    AppInfo(
        name: "Instagram",
        category: .사진및비디오,
        urlString: "https://apps.apple.com/kr/app/instagram/id389801252",
        ads: "관심사를 탐색하고 평범한 일상부터 인생의 특별한 순간까지 다양한 소식을 게시할 수 있습니다."),
    
    AppInfo(
        name: "Netflix",
        category: .엔터테인먼트,
        urlString: "https://apps.apple.com/kr/app/netflix/id363590051",
        ads: "전 세계의 인기 시리즈와 영화를 Netflix에서 만나보세요."),
    
    AppInfo(
        name: "배달의민족",
        category: .음식및음료,
        urlString: "https://apps.apple.com/kr/app/배달의민족/id378084485?ppid=25d2ac63-834d-4da6-a07d-84ae97a9f5a4",
        ads: "맛있는 음식을 넘어 생필품 배달까지 가장 많은 사람들이 쓰는 배달 앱을 지금 사용해보세요"),
    
    // 6. 이소영 
    AppInfo(
        name: "네이버지도",
        category: .내비게이션,
        urlString: "https://apps.apple.com/kr/app/naver-map-navigation/id311867728",
        ads: "장소, 버스, 지하철, 주소 등의 모든 정보를 검색창 하나로 검색할 수 있어요."),
    
    AppInfo(
        name: "모바일 신분증",
        category: .유틸리티,
        urlString: "https://apps.apple.com/kr/app/모바일-신분증-운전면허증-국가보훈등록증/id1599450372",
        ads: "정부가 개인 스마트폰에 발급하는 신분증으로, 현행 신분증과 동일한 법적 효력을 가지고 편리하게 사용할 수 있습니다."),
    
    AppInfo(
        name: "카카오T",
        category: .여행,
        urlString: "https://apps.apple.com/kr/app/카카오-t-택시-대리-주차-바이크-항공-퀵/id981110422",
        ads: "모든 이동을 위한 모빌리티 서비스입니다."),
    
    AppInfo(
        name: "지하철 종결자",
        category: .내비게이션,
        urlString: "https://apps.apple.com/kr/app/지하철-종결자-smarter-subway/id580488128",
        ads: "최신, 실시간 지하철 정보를 확인할 수 있습니다."),
    
    AppInfo(
        name: "코레일톡",
        category: .여행,
        urlString: "https://apps.apple.com/kr/app/코레일톡/id1000558562",
        ads: "코레일의 승차권 예약 앱입니다."),
    
    // 6. 김종혁
    /* 중복
    AppInfo(
        name: "KaKaoTalk",
        category: .소셜네트워킹,
        urlString: "https://apps.apple.com/kr/app/kakaotalk/id869223134?mt=12",
        ads: "언제 어디서나 무료로 즐기는 대한민국 대표 메신저!"),
    */
    
    AppInfo(
        name: "Goodnotes 6",
        category: .생산성,
        urlString: "https://apps.apple.com/kr/app/goodnotes-6/id1444383602",
        ads: "이미지, 스티커, 다이어그램, 낙서 등과 함께 필기가 가능한 나만의 템플릿 노트"),
    
    AppInfo(
        name: "멜론",
        category: .음악,
        urlString: "https://apps.apple.com/kr/app/멜론-melon/id1236050766?mt=12",
        ads: "No.1 뮤직플랫폼, 음악 감상 기능을 가장 완벽하게 멜론에서 들어요"),
    
    AppInfo(
        name: "KB스타뱅킹",
        category: .금융,
        urlString: "https://apps.apple.com/kr/app/kb스타뱅킹/id373742138",
        ads: "나만을 위한 단 하나의 은행, KB스타뱅킹을 통해 간편한 은행 이용을 즐겨보세요"),
    
    /* 중복
    AppInfo(
        name: "Notion Web Clipper",
        category: .생산성,
        urlString: "https://apps.apple.com/kr/app/notion-web-clipper/id1559269364?mt=12",
        ads: "와 앱스토어 영어로 되어있네요.;; 나만의 디자인으로 할일, 공부, 협업등을 공유하고 작성해보세요."),
     */
    
    // 6. 김수민
    AppInfo(
        name: "Notion Web Clipper",
        category: .생산성,
        urlString: "https://apps.apple.com/kr/app/notion-web-clipper/id1559269364?mt=12",
        ads: "내 위키, 문서, 프로젝트를 모두 한 곳에서 만나는 커넥티드 워크 스페이스. 사용하는 모든 업무 앱을 Notion 하나에 담아 팀원들과 함께하는 올인원 워크스페이스를 꾸려 보세요."),
    
    /* 중복
    AppInfo(
        name: "Goodnotes 6",
        category: .생산성,
        urlString: "https://apps.apple.com/kr/app/goodnotes-6/id1444383602",
        ads: "짧은 어플 설명: 디지털 노트, 실제 노트 한 권 가격으로 노트를 무제한으로 사용하세요. 어느 버전이든 여러분의 노트는 안전합니다!"),
     
    AppInfo(
        name: "KakaoTalk",
        category: .소셜네트워킹,
        urlString: "https://apps.apple.com/kr/app/goodnotes-6/id1444383602",
        ads: "디지털 노트, 실제 노트 한 권 가격으로 노트를 무제한으로 사용하세요. 어느 버전이든 여러분의 노트는 안전합니다!"),
    */

    AppInfo(
        name: "Airbnb",
        category: .여행,
        urlString: "https://apps.apple.com/kr/app/airbnb/id401626263",
        ads: "에어비앤비를 이용하면 어디서든 내 집 같은 편안함을 누릴 수 있습니다."),
    
    AppInfo(
        name: "오목의 달인",
        category: .게임,
        urlString: "https://apps.apple.com/kr/app/오목의-달인/id870442795",
        ads: "전세계 오목 고수들과 실시간 온라인 대국을 즐길 수 있습니다."),
]
