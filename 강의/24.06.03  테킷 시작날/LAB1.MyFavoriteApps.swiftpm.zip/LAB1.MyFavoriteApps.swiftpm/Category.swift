import SwiftUI

enum Category {
    case 개발자도구
    case 건강및피트니스
    case 게임
    case 그래픽및디자인
    case 금융
    case 날씨
    case 내비게이션
    case 뉴스
    case 도서
    case 라이프스타일
    case 비지니스
    case 사진및비디오
    case 생산성
    case 소셜네트워킹
    case 쇼핑
    case 스티커
    case 스포츠
    case 엔터테인먼트
    case 여행
    case 유틸리티
    case 음식및의료
    case 음악
    case 잡지및신문
    case 참고
    
    // 새로 추가
    case 음식및음료
}
