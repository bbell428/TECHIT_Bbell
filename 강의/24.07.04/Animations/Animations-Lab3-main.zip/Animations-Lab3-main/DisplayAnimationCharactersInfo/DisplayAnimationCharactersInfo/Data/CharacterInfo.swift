//
//  CharacterInfo.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import Foundation

struct CharacterInfo { //캐릭터 정보들을 저장하는 구조체
    var characterName: String
    var characterIntroduction: String
    var imageURL: String
}
