//
//  ContentView.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import SwiftUI

struct ContentView: View {
    
    let animations: [AnimationCharacterInfo] = [
        CrayonShinchan(),
        OshiNoKo(),
        DemonSlayer(),
        Pokemon(),
        Doraemon()
    ]
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(animations.indices, id: \.self) { i in
                    NavigationLink(destination: AnimationInfoView(characterInfo: animations[i].characterInfo)) {
                        Text(animations[i].animationTitle)
                    } //만약 리스트 중 하나를 클릭하면 AnimationInfoView로 넘어감
                }
            }
            .navigationTitle("애니메이션 목록")
        }
    }
}

#Preview {
    NavigationStack {
        ContentView()
    }
}
