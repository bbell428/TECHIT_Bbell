//
//  AnimationInfoView.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import SwiftUI

struct AnimationInfoView: View { //선택한 애니메이션의 캐릭터 정보를 보여주는 뷰
    
    var characterInfo: CharacterInfo?
    @State var isShowCharacterInfo: Bool = false //캐릭터 정보를 보여줄지 판단하기 위한 용도
    
    var body: some View {
        
        VStack {
            if let characterInfo {
                Button("\(characterInfo.characterName)") {
                    isShowCharacterInfo.toggle() //버튼을 누르면 토글(이전값이 true면 false, false면 true)
                }
                .padding()
                .background(Color(uiColor: .systemGray4))
                .font(.title)
                .bold()
                .foregroundStyle(.black)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                
                if isShowCharacterInfo {
                    Text(characterInfo.characterIntroduction)
                        .padding()
                        .font(.largeTitle)
                        .bold()
                    AsyncImage(url: URL(string: characterInfo.imageURL)) { image in
                        image.image?.resizable()
                            .aspectRatio(contentMode: .fit)
                    }
                } //만약 캐릭터 정보를 보여줘야 한다면 캐릭터 소개와 이미지 띄우기
            }
        }
    }
}

#Preview {
    AnimationInfoView()
}
