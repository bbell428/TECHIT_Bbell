//
//  DisplayAnimationCharactersInfoApp.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import SwiftUI

@main
struct DisplayAnimationCharactersInfoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
