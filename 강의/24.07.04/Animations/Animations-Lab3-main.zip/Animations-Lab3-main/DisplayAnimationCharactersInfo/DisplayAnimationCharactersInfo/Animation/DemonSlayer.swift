//
//  DemonSlayer.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import Foundation

class DemonSlayer: AnimationCharacterInfo { //애니메이션 정보 클래스를 상속받은 자식 클래스
    
    override init() { //생성자에서 프로퍼티 초기화
        super.init()
        
        super.animationTitle = "귀멸의 칼날"
        super.characterInfo = CharacterInfo(characterName: "탄지로", characterIntroduction: "히노카미 카구라", imageURL: "https://file.thisisgame.com/upload/site/pad/info/monsterscreen/20201029142833_4446.png")
    }
}
