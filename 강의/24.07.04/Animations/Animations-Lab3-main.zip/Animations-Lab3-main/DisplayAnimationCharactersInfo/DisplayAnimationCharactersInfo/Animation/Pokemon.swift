//
//  Pokemon.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import Foundation

class Pokemon: AnimationCharacterInfo { //애니메이션 정보 클래스를 상속받은 자식 클래스
    
    override init() { //생성자에서 프로퍼티 초기화
        super.init()
        
        super.animationTitle = "포켓몬"
        super.characterInfo = CharacterInfo(characterName: "메타몽", characterIntroduction: "몸의 세포 구성을 스스로 바꿔서 다른 생명체로 변신한다.", imageURL: "https://t2.daumcdn.net/thumb/R720x0/?fname=http://t1.daumcdn.net/brunch/service/user/7N6y/image/Olal9MOOsipSF93xeiaNQf2jeXg.jpg")
    }
}
