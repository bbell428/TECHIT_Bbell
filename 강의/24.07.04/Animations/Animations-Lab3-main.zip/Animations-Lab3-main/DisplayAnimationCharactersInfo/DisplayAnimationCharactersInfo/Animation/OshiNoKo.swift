//
//  OshiNoKo.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import Foundation

class OshiNoKo: AnimationCharacterInfo { //애니메이션 정보 클래스를 상속받은 자식 클래스
    
    override init() { //생성자에서 프로퍼티 초기화
        super.init()
        
        super.animationTitle = "최애의 아이"
        super.characterInfo = CharacterInfo(characterName: "아이 호시노", characterIntroduction: "이 말은 절대로 거짓말이 아니야", imageURL: "https://img.onnada.com/2023/0421/thumb_991469724_e2d00e91_892_p0.jpg")
    }
}
