//
//  AnimationCharacterInfo.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import Foundation

class AnimationCharacterInfo { //애니메이션 제목, 캐릭터 정보를 가지고 있는 부모 클래스
    
    var animationTitle: String = ""
    var characterInfo: CharacterInfo = CharacterInfo(characterName: "", characterIntroduction: "", imageURL: "")

    func getCharacterInfo() -> CharacterInfo {
        return characterInfo //모든 자식클래스들에서 공통으로 필요한 기능
    }
}
