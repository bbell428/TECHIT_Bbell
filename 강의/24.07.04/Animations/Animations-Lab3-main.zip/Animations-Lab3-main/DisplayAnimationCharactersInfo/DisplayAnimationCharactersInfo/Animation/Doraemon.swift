//
//  Doraemon.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import Foundation

class Doraemon: AnimationCharacterInfo { //애니메이션 정보 클래스를 상속받은 자식 클래스
    
    override init() { //생성자에서 프로퍼티 초기화
        super.init()
        
        super.animationTitle = "도라에몽"
        super.characterInfo = CharacterInfo(characterName: "도라에몽", characterIntroduction: "좋아, 대나무 헬리콥터", imageURL: "https://upload.wikimedia.org/wikipedia/ko/c/cd/Doraemon.PNG")
    }
}
