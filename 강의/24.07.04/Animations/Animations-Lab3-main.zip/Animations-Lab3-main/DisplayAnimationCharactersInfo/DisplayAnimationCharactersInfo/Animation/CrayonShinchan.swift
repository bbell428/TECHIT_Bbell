//
//  CrayonShinchan.swift
//  DisplayAnimationCharactersInfo
//
//  Created by 홍재민 on 7/4/24.
//

import Foundation

class CrayonShinchan: AnimationCharacterInfo { //애니메이션 정보 클래스를 상속받은 자식 클래스
    
    override init() { //생성자에서 프로퍼티 초기화
        super.init()
        
        super.animationTitle = "짱구"
        super.characterInfo = CharacterInfo(characterName: "짱구", characterIntroduction: "떡잎마을 유치원 대장 ENTP 짱구", imageURL: "https://res.heraldm.com/content/image/2015/03/06/20150306001045_0.jpg")
    }
}
