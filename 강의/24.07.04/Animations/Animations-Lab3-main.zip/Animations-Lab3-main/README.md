# 애니와 함께
애니메이션 제목 클릭시 주인공 이름과 사진, 설명이 보입니다.

# 주요기능
- Class 사용
- Struct 사용

# 작동환경
- Xcode: Version 15.4
- iOS: Version 17.5


# 개발자
- 김동경
- 김수민
- 김종혁
- 홍재민
- 홍지수

# 라이선스
Licensed under the [MIT](LICENSE) license.
