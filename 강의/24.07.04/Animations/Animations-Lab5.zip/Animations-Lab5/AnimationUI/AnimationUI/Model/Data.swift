//
//  Data.swift
//  AnimationUI
//
//  Created by Hyeonjeong Sim on 7/4/24.
//

import Foundation

// 애니메이션
struct Animation: Identifiable {
    let id: UUID = UUID()
    let title: String
    let characters: [Character]
}
// 요런식으로 
// 주인공
struct Character: Identifiable {
    let id: UUID = UUID()
    let name: String
    let details: String
    var imageURL: String
}

// 애니메이션 등장인물 이름, 세부정보
let demonSlayer = Animation(title: "demonSlayer", characters: [
    Character(name: "탄지로", details: "붉은색 머리카락\n맑고 깊은 붉은 눈동자의 소유자.", imageURL:"https://i.namu.wiki/i/UqMosXxvcJj1zIiaeCo7j9y2Tz9WLDjEWhnPq7Vbu6QZwi9QSWak2lEMql583r_0jHKmh_rmh0WzoW4RUUXWMnD4ruhAOnYNPQk0HkA7DMcf2F5NIWU6_RFZNmjByrKZlMeESDHeC2KkQpjBusr-vw.webp" ),
    Character(name: "네즈코", details: "긴 장발에 윗 속눈썹 한가닥이 포인트\n아래로 처진 눈매, 분홍색 눈동자.", imageURL:"https://i.namu.wiki/i/VCDDTZs8zt2CntO_g5dRYRHRTFWdw335UDoIMkxlaFHzNBFYXWAcWxmTnZLDvHd7h2yaHNpEymqDSSDIowJjw8hlDLKkRFw0lOP4db1n5akkDn_kLP5Ct3XiU7inb0d0kzL4HNE7HXnHaDkDkyY3qA.webp"),
    Character(name: "렌고쿠", details: "눈동자는 노란빛과 붉은빛을 띄고 있고\n머리카락은 전체적으로 노란색 장발.", imageURL:"https://i.namu.wiki/i/Uv2YE0dB8moJxA6UzwofVqvvvP6DbSx3LOOpxc88cxxSv1tfwb6vJRYmKe_gyzD7PvWsWxtaQzLjAbRpKgzIbfSdPtX4ivJNZEBnWO5IzgZFoaTZJ3vzAjG-Qq26n0nVXgPCsG8PHVo4R7R6pne0rA.webp"),
    Character(name: "무잔", details: "곱슬머리에 5:5 가르마를 탄\n분홍색 눈동자를 하고 있는 도깨비.", imageURL:"https://i.namu.wiki/i/IIzninIpSMp2Gt86z7iQM7u18A6wxZiOLnIivlQCM-YXMISvPpYk5ygeXsziCTCdt4Xfc-MPt8FTy4yYxnCMBFj7R5GtL_AQGSB8-j-FeLHgJXeGdU9mQcQkj0crWBkAV53Pa54Ha-f4mT-yAIm8hw.webp"),
])


let chiikawa = Animation(title: "치이카와", characters: [
    Character(name: "치이카와", details: "살짝 울보지만 상냥한 성격. 풀뽑기나 토벌 등을 하며 생활하고 있다.", imageURL:"https://i.namu.wiki/i/RtAO7RUk0CkOy0ii6eg2bVBra_lnJeWknXJalqmi1uUuz0u6VXzEvDQcwAW9HKMyI29UjDVNrt76UUAzvKDMmaxsDfkLtW34oZWke2lLfUEQJ5lv0yRBJwZ0y000Wh8A-kAEE06UA8pWkmH1N507Tg.webp"),
    Character(name: "하치와레", details: "치이카와의 친구. 밝고 긍정적이다.동굴에서 생활하고 있다.", imageURL:"https://i.namu.wiki/i/rnF3I2lDGkeG2VGLXXzGmMmDhxA43EVahFZyugJCSJWSK8M1sgpA7GMWiPwgWaZuhpGo9PC-Nfo_2jQ7p8OVsDIqqtdw1JPTTPKCv3FKHMyk7zH07441dCB1G7HSoVifN1hMLFSc_93hARb7HrZ1ew.webp"),
    Character(name: "우사기", details: "치이카와의 친구. '우라', '야하' 하고 곧잘 소리를 지른다", imageURL:"https://i.namu.wiki/i/OxlEGpE0wJD1pY6IuinPwtaXuGaLah37Y0suioKsC5HhrrU70xUSioyxBI3fyr3FDTX9unWoF0itgbVXPyfJdsLJpYqz03xDo6ad89kSrNutZD2K6gIhSEMxg4R1SN7_EtRc4ayd1cnEqUtzbsj7Tg.webp"),
])


let onesfavoritechild = Animation(title: "최애의 아이", characters: [
    Character(name: "호시노 아이", details: "남색같은 짙은 보라색 긴 생머리와 분홍색 포인트\n분홍색에 가까운 짙은 자주색 눈동자", imageURL:"https://i.namu.wiki/i/EXuGhVvGRDNtkuaSL7QZdHBOKGpI6L-Zb0k0QHeLxkAKfEK4es_Jg5eMluPuIgFZr6eainn41vPW9F91EyoJUvulmGtKRf2G1StYdvytGP0gyd1O2NZIV_4IPzidDyV_fGjVTJ0MkylenI-69nsoYA.webp"),
    Character(name: "호시노 아쿠아마린", details: "아이돌 느낌의 미소년", imageURL:"https://i.namu.wiki/i/9EShoUsUuws43GX-fhbbcTUW4EXV646AYZ4FS3iN25jBP5T9TTSdfZgiGmOQfMpdhPAdvlAMn4tbiWmlBE3zh0u7Jysj6DlBeWlaENOccWp6kjUNkegpsDJzcbIVEbTTTqVtZO630IQtcXChyzHpZw.webp"),
    Character(name: "호시노 루비", details: "쌍둥이 오빠 아쿠아와 같은 금발에\n 그녀의 이름인 루비처럼 붉은 눈을 가지고 있다", imageURL:"https://i.namu.wiki/i/Mi3biQScRWI7gppZrcjTJewdKXAdn4Oo6p_cFg6UmqD6g0BGm5UDgr5iOdklJOBbyv6TVVX7x9bT_mPb4RB1DGKyuYt8-I-bzu9U2A_RUYFga62gHO9fB7dj3Ju7W3BwPCPXJwtsRWdtyhBA2XfNdA.webp"),
])


let animations = [demonSlayer, chiikawa, onesfavoritechild] // 요거

