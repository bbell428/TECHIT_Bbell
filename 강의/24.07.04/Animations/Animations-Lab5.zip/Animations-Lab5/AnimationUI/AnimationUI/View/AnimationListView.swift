//
//  AnimationView.swift
//  AnimationUI
//
//  Created by Hyeonjeong Sim on 7/4/24.
//

import SwiftUI

struct AnimationListView: View {
    var body: some View {
        List{
            Section("애니메이션") {
                // [1,2,3,4] 4개를 전부 다 도는것
                ForEach(animations) { animation in
                    // 1. 데몬슬레이어 =
                    NavigationLink(destination: CharcterListView(animation: animation)) {
                        // 현재 화면에 보여지는 것
                        Text("\(animation.title)")
                    }
                }
            }
        }
        .navigationTitle("애니메이션 목록")
    }
}

#Preview {
    NavigationStack {
        AnimationListView()
    }
}
