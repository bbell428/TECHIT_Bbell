//
//  ContentView.swift
//  AnimationUI
//
//  Created by Hyeonjeong Sim on 7/4/24.
//

import SwiftUI
// FILO 먼저 들어온게 제일 나중에 나간다 - stack
// FIFO 먼저 들어온게 첫번째로 나간다 - Queue
struct ContentView: View {
    var body: some View {
        NavigationStack { // 쌓을때 Push 뒤로갈때 Pop
            AnimationListView()
        }
    }
}

#Preview {
    ContentView()
}
