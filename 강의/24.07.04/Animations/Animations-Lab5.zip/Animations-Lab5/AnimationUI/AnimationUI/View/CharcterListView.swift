//
//  CharcterListView.swift
//  AnimationUI
//
//  Created by Hyeonjeong Sim on 7/4/24.
//

import SwiftUI

struct CharcterListView: View {
    // 귀칼을 눌렀을때는 귀칼이다
    let animation: Animation
    // 코드를 짜실떄 command 를 누르면서 이게 어디서 왔는지 추적하면서 하면 도움이 됩니다 !
    var body: some View{
        // 이 부분에서 이게 어떤걸 받아오는거지 ? 
        // 그럼 캐릭터가 뭘 가르키는지 알 수 있어요 
        List(animation.characters) { character in
            VStack {
                Text(character.name)
                    .font(.headline)
                AsyncImage(url: URL(string: character.imageURL))
                Text(character.details)
            }
        }
    }
}

#Preview {
    CharcterListView(animation: onesfavoritechild)
}
