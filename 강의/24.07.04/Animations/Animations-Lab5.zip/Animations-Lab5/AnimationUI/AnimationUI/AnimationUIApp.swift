//
//  AnimationUIApp.swift
//  AnimationUI
//
//  Created by Hyeonjeong Sim on 7/4/24.
//

import SwiftUI

@main
struct AnimationUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
