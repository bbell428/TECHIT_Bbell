//
//  HelloWorldApp.swift
//  HelloWorld
//
//  Created by Jongwook Park on 7/3/24.
//

import SwiftUI

@main
struct HelloWorldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
