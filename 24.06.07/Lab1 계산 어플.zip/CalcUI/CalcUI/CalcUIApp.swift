//
//  CalcUIApp.swift
//  CalcUI
//
//  Created by 이소영 on 6/7/24.
//

import SwiftUI

@main
struct CalcUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
