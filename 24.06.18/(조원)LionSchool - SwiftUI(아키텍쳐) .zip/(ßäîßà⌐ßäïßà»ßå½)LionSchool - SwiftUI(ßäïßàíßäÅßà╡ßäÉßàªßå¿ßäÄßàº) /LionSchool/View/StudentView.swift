import SwiftUI

struct StudentView: View {
    let schoolClass: SchoolClass
    
    var body: some View {
        // 학생
        List(schoolClass.students) { student in
            VStack(alignment: .leading) {
                Text("\(student.name)")
                    .font(.title)
                    .foregroundColor(.blue)
                    .padding(.bottom, 10)
                Text("MBTI: \(student.mbti)")
                Text("별자리: \(student.star)")
                Text("장기: \(student.talent)")
            }.padding()
        }
        .navigationTitle("\(schoolClass.name)")
        
    }
}

#Preview {
    StudentView(schoolClass:
        SchoolClass(name: "애니메이션반", campaign: "짱구는 사실 35살", students: [
            Student(name: "짱구", talent: "내용 입력(애니)", mbti: "ENFP", star: "사자자리"),
            Student(name: "도라에몽", talent: "내용 입력(애니)", mbti: "", star: ""),
            Student(name: "흰둥이", talent: "내용 입력(애니)", mbti: "", star: ""),
            Student(name: "큐티니", talent: "내용 입력(애니)", mbti: "", star: ""),
            Student(name: "하니", talent: "내용 입력(애니)", mbti: "", star: ""),
            Student(name: "하츄핑", talent: "내용 입력(애니)", mbti: "", star: "")
        ]))
}
