//
//  GradeExist.swift
//  LionSchool
//
//  Created by 김효정 on 6/18/24.
//

import Foundation

// 학년 표어
protocol GradeExist {
    var grade: String { get set }
}
