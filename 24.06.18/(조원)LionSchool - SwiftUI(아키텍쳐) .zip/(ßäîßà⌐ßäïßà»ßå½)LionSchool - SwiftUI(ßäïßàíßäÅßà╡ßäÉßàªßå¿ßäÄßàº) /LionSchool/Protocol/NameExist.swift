//
//  NameExist.swift
//  LionSchool
//
//  Created by 김효정 on 6/18/24.
//

import Foundation

protocol NameExist {
    var name: String { get set }
}
