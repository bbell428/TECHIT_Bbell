//
//  PersonalProperty.swift
//  LionSchool
//
//  Created by 김효정 on 6/18/24.
//

import Foundation

// 학생 개인 표어
protocol PersonalProperty {
    var talent: String { get set }
    var mbti: String { get set }
    var star: String { get set }
}
