//
//  CampaignExist.swift
//  LionSchool
//
//  Created by 김효정 on 6/18/24.
//

import Foundation

// 학급 표어
protocol CampaignExist {
    var campaign: String { get set }
}
