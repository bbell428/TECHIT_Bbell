//
//  CampaignExist.swift
//  LionSchool
//
//  Created by Jongwook Park on 6/18/24.
//

import Foundation

protocol CampaignExist {
    var campaign: String { get set }
}
