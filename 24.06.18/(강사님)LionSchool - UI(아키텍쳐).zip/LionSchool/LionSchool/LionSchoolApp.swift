//
//  LionSchoolApp.swift
//  LionSchool
//
//  Created by Jongwook Park on 6/17/24.
//

import SwiftUI

@main
struct LionSchoolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
