//
//  LionSchoolApp.swift
//  LionSchool
//
//  Created by 이소영 on 6/17/24.
//

import SwiftUI

@main
struct LionSchoolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
